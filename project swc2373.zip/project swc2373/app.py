from flask import Flask, render_template

app = Flask(__name__)

# Route for the main page with Jitsi integration
@app.route('/')
def index():
    return render_template('index.html', room_name="StudentSocialPortalRoom")

if __name__ == '__main__':
    app.run(debug=True)
